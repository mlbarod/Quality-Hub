import assert from "node:assert/strict"
import { once } from "node:events"
import test from "node:test"

import viteConfig from "../vite.config.mjs"

import {
  builtStaticDir,
  createQualityHubServer,
  parsePort,
  resolvePort,
  resolveServeMode,
  resolveStaticPath,
  sourceStaticDir,
} from "../server.mjs"

async function startTestServer() {
  const server = createQualityHubServer({ staticDir: sourceStaticDir })
  server.listen(0, "127.0.0.1")
  await once(server, "listening")

  const address = server.address()
  return {
    server,
    baseUrl: `http://127.0.0.1:${address.port}`,
  }
}

test("PORT는 유효한 포트 번호만 허용한다", () => {
  assert.equal(parsePort("4173"), 4173)
  assert.equal(parsePort("5500"), 5500)
  assert.throws(() => parsePort("0"), /between 1 and 65535/)
  assert.throws(() => parsePort("65536"), /between 1 and 65535/)
  assert.throws(() => parsePort("abc"), /between 1 and 65535/)
})

test("명령행에서 5500 포트를 선택할 수 있다", () => {
  assert.equal(resolvePort(["--port", "5500"], "4173"), 5500)
  assert.equal(resolvePort(["--port=5500"], "4173"), 5500)
  assert.equal(resolvePort([], "4173"), 4173)
  assert.throws(() => resolvePort(["--port"], "4173"), /between 1 and 65535/)
})

test("정적 경로가 prototype 밖으로 벗어나지 못한다", () => {
  assert.equal(resolveStaticPath("/%2e%2e/README.md", sourceStaticDir).forbidden, true)
  assert.equal(resolveStaticPath("/%E0%A4%A", sourceStaticDir).badRequest, true)
})

test("실행용 정적 서버는 Vite 빌드 산출물을 기본으로 제공한다", () => {
  assert.equal(resolveStaticPath("/index.html").filePath, `${builtStaticDir}/index.html`)
})

test("server.mjs는 기본적으로 소스를 실시간 제공하고 정적 모드는 명시적으로 선택한다", () => {
  assert.equal(resolveServeMode([]), "source")
  assert.equal(resolveServeMode(["--built"]), "built")
})

test("외부 개발 도메인을 Vite 서버에서 허용한다", () => {
  assert.ok(viteConfig.server.allowedHosts.includes("sanghyun--sanghyun-dev.cdep1.samsungds.net"))
})

test("메인 화면과 정적 자산을 제공한다", async (t) => {
  const { server, baseUrl } = await startTestServer()
  t.after(() => server.close())

  const indexResponse = await fetch(`${baseUrl}/`)
  assert.equal(indexResponse.status, 200)
  assert.match(indexResponse.headers.get("content-type"), /^text\/html/)
  assert.equal(indexResponse.headers.get("x-content-type-options"), "nosniff")
  assert.match(await indexResponse.text(), /<title>Quality Hub<\/title>/)

  const cssResponse = await fetch(`${baseUrl}/styles.css`)
  assert.equal(cssResponse.status, 200)
  assert.match(cssResponse.headers.get("content-type"), /^text\/css/)
})

test("HEAD, 미존재 경로와 허용하지 않는 메서드를 처리한다", async (t) => {
  const { server, baseUrl } = await startTestServer()
  t.after(() => server.close())

  const headResponse = await fetch(`${baseUrl}/app.js`, { method: "HEAD" })
  assert.equal(headResponse.status, 200)
  assert.equal(await headResponse.text(), "")

  assert.equal((await fetch(`${baseUrl}/missing`)).status, 404)

  const postResponse = await fetch(`${baseUrl}/`, { method: "POST" })
  assert.equal(postResponse.status, 405)
  assert.equal(postResponse.headers.get("allow"), "GET, HEAD")
})
